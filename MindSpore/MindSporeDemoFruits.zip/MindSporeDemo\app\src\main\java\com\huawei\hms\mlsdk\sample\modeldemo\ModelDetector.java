package com.huawei.hms.mlsdk.sample.modeldemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.util.Log;
import android.widget.Toast;

import com.huawei.agconnect.config.AGConnectServicesConfig;
import com.huawei.hmf.tasks.OnFailureListener;
import com.huawei.hmf.tasks.OnSuccessListener;
import com.huawei.hmf.tasks.Task;
import com.huawei.hms.mlsdk.common.MLApplication;
import com.huawei.hms.mlsdk.common.MLException;
import com.huawei.hms.mlsdk.custom.MLCustomLocalModel;
import com.huawei.hms.mlsdk.custom.MLCustomRemoteModel;
import com.huawei.hms.mlsdk.custom.MLModelDataType;
import com.huawei.hms.mlsdk.custom.MLModelExecutor;
import com.huawei.hms.mlsdk.custom.MLModelExecutorSettings;
import com.huawei.hms.mlsdk.custom.MLModelInputOutputSettings;
import com.huawei.hms.mlsdk.custom.MLModelInputs;
import com.huawei.hms.mlsdk.custom.MLModelOutputs;
import com.huawei.hms.mlsdk.model.download.MLLocalModelManager;
import com.huawei.hms.mlsdk.model.download.MLModelDownloadListener;
import com.huawei.hms.mlsdk.model.download.MLModelDownloadStrategy;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class ModelDetector {
    private static final String TAG = "HMS_HIAI_MINDSPORE";

    private static final int BITMAP_SIZE = 224;
    private static final int BITMAP_WIDTH = 224;
    private static final int BITMAP_HEIGHT = 224;
    private static final float[] IMAGE_MEAN = new float[] {0.485f * 255f, 0.456f * 255f, 0.406f * 255f};
    private static final float[] IMAGE_STD = new float[] {0.229f * 255f, 0.224f * 255f, 0.225f * 255f};

    private List<String> labelList;
    private Context mContext;
    private volatile MLModelExecutor modelExecutor;

    private String mModelName;
    private String mModelFullName; // .om, .mslite, .ms  .mc
    private String mModelLabelFile;
    private volatile boolean loadOk;

    public ModelDetector(Context context) {
        mContext = context;
        mModelName = "mindspore";
        mModelFullName = "mindspore.ms";  // the name in assets dir
        mModelLabelFile = "labels.txt";
        loadOk = false;
    }

    public void loadModelFromAssets() {
        labelList = readLabels(mContext, mModelLabelFile);
        MLCustomLocalModel localModel =
                new MLCustomLocalModel.Factory(mModelName).setAssetPathFile(mModelFullName).create();
        //you can use the following code to load model from filesystem
        //MLCustomLocalModel localModel = new MLCustomLocalModel.Factory(mModelName).setLocalFullPathFile(modelFilePath).create();
        MLModelExecutorSettings settings = new MLModelExecutorSettings.Factory(localModel).create();
        try {
            modelExecutor = MLModelExecutor.getInstance(settings);
            loadOk = true;
        } catch (MLException error) {
            error.printStackTrace();
        }
    }

    /**
     *  Recommend using HMS cloud hosting service, you can upload the model to HMS cloud hosting service, app can download your model and load it;
     *  Please follow these steps:
     *  1. https://developer.huawei.com/consumer/cn/doc/development/HMSCore-Guides/config-agc-0000001050990353
     *  2. https://developer.huawei.com/consumer/cn/doc/development/HMSCore-Guides/hosting-on-the-cloud-0000001051824955
     *
     */
    public void loadModelFromHMSCloudHosting() {
        labelList = readLabels(mContext, mModelLabelFile);
        AGConnectServicesConfig config = AGConnectServicesConfig.fromContext(this.mContext);
        MLApplication.getInstance().setAccessToken(config.getString("client/api_key"));
        final MLModelDownloadStrategy strategy = new MLModelDownloadStrategy
                .Factory()
                .needWifi()
                .setRegion(MLModelDownloadStrategy.REGION_DR_CHINA) // set Region： supported：REGION_DR_CHINA，REGION_DR_AFILA，REGION_DR_EUROPE，REGION_DR_RUSSIA。
                .create();
        String remoteModelName = "mindspore"; // your model name
        final MLCustomRemoteModel customRemoteModel = new MLCustomRemoteModel.Factory(remoteModelName).create();
        final Task<Void> task = MLLocalModelManager.getInstance().downloadModel(customRemoteModel, strategy, new MLModelDownloadListener() {
            @Override
            public void onProcess(long alreadyDownLength, long totalLength) {
                Log.d(TAG, "current:" + alreadyDownLength + " total:" + totalLength);
                if(alreadyDownLength == totalLength) { //download complete
                    Log.d(TAG, "model download success");
                }
            }
        });
        new Thread() {
            @Override
            public void run() {
                while(!task.isComplete()) {
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    Log.d(TAG, "wait task isComplete");
                }
                try {
                    File file = MLLocalModelManager.getInstance().getSyncRecentModelFile(customRemoteModel);
                    if(file != null) {
                        Log.d(TAG, "model path:" + file.getAbsolutePath());
                        MLCustomLocalModel localModel = new MLCustomLocalModel.Factory(remoteModelName).setLocalFullPathFile(file.getAbsolutePath()).create();
                        MLModelExecutorSettings settings = new MLModelExecutorSettings.Factory(localModel).create();
                        modelExecutor = MLModelExecutor.getInstance(settings);
                        loadOk = true;
                        Log.d(TAG, "load model hms success");
                    } else {
                        Log.d(TAG, "model file is null");
                    }
                } catch (MLException e) {
                    e.printStackTrace();
                }
            }
        }.start();


    }

    public boolean isLoadOk() {
        return loadOk;
    }

    public void predict(Bitmap bitmap, OnSuccessListener<MLModelOutputs> successCallback, OnFailureListener failureCallback) {
        if(!this.isLoadOk()) {
            Toast.makeText(this.mContext, "the model does not init ok", Toast.LENGTH_LONG).show();
            return;
        }
        Bitmap inputBitmap = resizeBitMap(bitmap);
        Object input = preprocess(inputBitmap);
        Log.d(TAG, "interpret pre process");

        MLModelInputs inputs = null;

        try {
            inputs = new MLModelInputs.Factory().add(input).create();
        } catch (MLException e) {
            Log.e(TAG, "add inputs failed! " + e.getMessage());
        }

        MLModelInputOutputSettings inOutSettings = null;
        try {
            MLModelInputOutputSettings.Factory settingsFactory = new MLModelInputOutputSettings.Factory();
            settingsFactory.setInputFormat(0, MLModelDataType.FLOAT32, new int[] {1, BITMAP_SIZE, BITMAP_SIZE, 3});
            ArrayList<int[]> outputSettingsList = new ArrayList<>();
            int[] outputShape = new int[] {1, labelList.size()};
            outputSettingsList.add(outputShape);
            for (int i = 0; i < outputSettingsList.size(); i++) {
                settingsFactory.setOutputFormat(i, MLModelDataType.FLOAT32, outputSettingsList.get(i));
            }
            inOutSettings = settingsFactory.create();
        } catch (MLException e) {
            Log.e(TAG, "set input output format failed! " + e.getMessage());
        }

        Log.d(TAG, "interpret start");
        modelExecutor.exec(inputs, inOutSettings).addOnSuccessListener(successCallback).addOnFailureListener(failureCallback);
    }

    public void close() {
        try {
            modelExecutor.close();
        } catch (IOException error) {
            error.printStackTrace();
        }
    }

    public String resultPostProcess(MLModelOutputs output) {
        float[][] result = output.getOutput(0);
        float[] probabilities = result[0];
        return getPredictLabelInf(probabilities);
    }

    private Bitmap resizeBitMap(Bitmap bitmap) {
        int cropSize = Math.min(bitmap.getWidth(), bitmap.getHeight());
        Bitmap cropBitmap = getCropBitmap(bitmap, cropSize, cropSize);
        return Bitmap.createScaledBitmap(cropBitmap, BITMAP_WIDTH, BITMAP_HEIGHT, false);
    }

    private Bitmap getCropBitmap(Bitmap input, int targetWidth, int targetHeight) {
        Bitmap output = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
        int srcL,srcR, srcT, srcB, dstL, dstR, dstT, dstB;
        int w = input.getWidth();
        int h = input.getHeight();
        if (targetWidth > w) { // padding
            srcL = 0;
            srcR = w;
            dstL = (targetWidth - w) / 2;
            dstR = dstL + w;
        } else { // cropping
            dstL = 0;
            dstR = targetWidth;
            srcL = (w - targetWidth) / 2;
            srcR = srcL + targetWidth;
        }
        if (targetHeight > h) { // padding
            srcT = 0;
            srcB = h;
            dstT = (targetHeight - h) / 2;
            dstB = dstT + h;
        } else { // cropping
            dstT = 0;
            dstB = targetHeight;
            srcT = (h - targetHeight) / 2;
            srcB = srcT + targetHeight;
        }
        Rect src = new Rect(srcL, srcT, srcR, srcB);
        Rect dst = new Rect(dstL, dstT, dstR, dstB);
        new Canvas(output).drawBitmap(input, src, dst, null);
        return output;
    }

    private Object preprocess(Bitmap inputBitmap) {
        final float[][][][] input = new float[1][BITMAP_SIZE][BITMAP_SIZE][3];
        for (int h = 0; h < BITMAP_SIZE; h++) {
            for (int w = 0; w < BITMAP_SIZE; w++) {
                int pixel = inputBitmap.getPixel(w, h);
                input[0][h][w][0] = ((Color.red(pixel) - IMAGE_MEAN[0])) / IMAGE_STD[0];
                input[0][h][w][1] = ((Color.green(pixel) - IMAGE_MEAN[1])) / IMAGE_STD[1];
                input[0][h][w][2] = ((Color.blue(pixel) - IMAGE_MEAN[2])) / IMAGE_STD[2];
            }
        }
        return input;
    }

    private boolean dumpBitmapInfo(Bitmap bitmap) {
        if (bitmap == null) {
            return true;
        }
        final int width = bitmap.getWidth();
        final int height = bitmap.getHeight();
        Log.e(TAG, "bitmap width is " + width + " height " + height);
        return false;
    }

    private String getPredictLabelInf(float[] result) {
        return processResult(this.labelList, result);
    }

    private static final int PRINT_LENGTH = 10;

    private static String processResult(List<String> labelList, float[] probabilities) {
        Map<String, Float> localResult = new HashMap<>();
        ValueComparator compare = new ValueComparator(localResult);
        for (int i = 0; i < probabilities.length; i++) {
            localResult.put(labelList.get(i), probabilities[i]);
        }
        TreeMap<String, Float> result = new TreeMap<>(compare);
        result.putAll(localResult);

        StringBuilder builder = new StringBuilder();

        int total = 0;
        DecimalFormat df = new DecimalFormat("0.00%");
        for (Map.Entry<String, Float> entry : result.entrySet()) {
            if (total == PRINT_LENGTH || entry.getValue() <= 0) {
                break;
            }

            builder.append("No ")
                    .append(total)
                    .append("：")
                    .append(entry.getKey())
                    .append(" / ")
                    .append(df.format(entry.getValue()))
                    .append(System.lineSeparator());
            total++;
        }

        return builder.toString();
    }

    private static class ValueComparator implements Comparator<String> {
        Map<String, Float> base;

        ValueComparator(Map<String, Float> base) {
            this.base = base;
        }

        @Override
        public int compare(String o1, String o2) {
            if (base.get(o1) >= base.get(o2)) {
                return -1;
            } else {
                return 1;
            }
        }
    }

    private static ArrayList<String> readLabels(Context context, String assetFileName) {
        ArrayList<String> result = new ArrayList<>();
        InputStream is = null;
        try {
            is = context.getAssets().open(assetFileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8")); // 构造一个BufferedReader类来读取文件
            String readString;
            while ((readString = br.readLine()) != null) {
                result.add(readString);
            }
            br.close();
        } catch (IOException error) {
            Log.e(TAG, "Asset file doesn't exist: " + error.getMessage());
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException error) {
                    Log.e(TAG, "close failed: " + error.getMessage());
                }
            }
        }
        return result;
    }
}
